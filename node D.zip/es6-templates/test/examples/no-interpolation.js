var s = `str`;
assert.equal(s, 'str');
