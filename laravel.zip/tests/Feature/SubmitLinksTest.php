<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class SubmitLinksTest extends TestCase
{
    use RefreshDatabase;

/** @test */
    function guest_can_submit_new_link()
    {
        $response = $this->post('/submit',[
            'title' => 'Sample Title',
            'url' => 'http://example.com',
            'description' => 'Sample description',
        ]);

        $this->assertDatabaseHas('links',[
            'title'=>'Sample Title'
        ]);

        $response
            ->assertStatus(302)
            ->assertHeader('Location',url(''));

        $this
            ->get('/')
            ->assertSee('Sample Title');
    }

    /** @test */
    function link_not_created_if_validation_fails()
    {
        $response = $this->post('/submit');

        $response->assertSessionHasErrors(['title','url','description']);
    }

    /** @test */
function max_length_fails_when_too_long()
{
    $this->withoutExceptionHandling();

    $title = str_repeat('a', 256);
    $description = str_repeat('a', 256);
    $url = 'http://';
    $url .= str_repeat('a', 256 - strlen($url));

    try {
        $this->post('/submit', compact('title', 'url', 'description'));
    } catch(ValidationException $e) {
        $this->assertEquals(
            'The title may not be greater than 255 characters.',
            $e->validator->errors()->first('title')
        );

        $this->assertEquals(
            'The url may not be greater than 255 characters.',
            $e->validator->errors()->first('url')
        );

        $this->assertEquals(
            'The description may not be greater than 255 characters.',
            $e->validator->errors()->first('description')
        );

        return;
    }

    $this->fail('Max length should trigger a ValidationException');
}
}
