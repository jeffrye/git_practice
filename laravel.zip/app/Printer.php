<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Printer extends Model
{
    //
    protected $table = 'printer';
    protected $primaryKey = 'ID';
    public $timestamps = false;
}
