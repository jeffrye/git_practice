<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use DataTables;
use App\Printer;

class PrinterController extends Controller
{
    //
    public function index()
    {
    	//$printer=DB::table('printer')->get();
    	//return view('index',['printer' => $printer]);
    	return view('list_printer');
    }

	/**
	 * Displays datatables front end view
	 *
	 * @return \Illuminate\View\View
	 */
	public function getIndex()
	{
	    return view('datatables.index');
	}

	/**
	 * Process datatables ajax request.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function anyData()
	{
	    return Datatables::of(Printer::query())->make(true);
	}

    public function json(){
        return Datatables::of(Printer::all())->make(true);
    }

    // method untuk menampilkan view form tambah pegawai
	public function add()
	{

		// memanggil view tambah
		return view('add');

	}

	public function store(Request $request)
	{
		// insert data ke table pegawai
		DB::table('printer')->insert([
			'pegawai_nama' => $request->nama,
			'pegawai_jabatan' => $request->jabatan,
			'pegawai_umur' => $request->umur,
			'pegawai_alamat' => $request->alamat
		]);
		// alihkan halaman ke halaman pegawai
		return redirect('/printer');
	 
	}

	// method untuk edit data pegawai
	public function edit($id)
	{
		// mengambil data pegawai berdasarkan id yang dipilih
		$pegawai = DB::table('printer')->where('ID',$id)->get();
		// passing data pegawai yang didapat ke view edit.blade.php
		return view('edit',['printer' => $printer]);

	}

	// update data pegawai
	public function update(Request $request)
	{
		// update data pegawai
		DB::table('printer')->where('ID',$request->id)->update([
			'pegawai_nama' => $request->nama,
			'pegawai_jabatan' => $request->jabatan,
			'pegawai_umur' => $request->umur,
			'pegawai_alamat' => $request->alamat
		]);
		// alihkan halaman ke halaman pegawai
		return redirect('/printer');
	}

	// method untuk hapus data pegawai
	public function delete($id)
	{
		// menghapus data pegawai berdasarkan id yang dipilih
		DB::table('printer')->where('ID',$id)->delete();
			
		// alihkan halaman ke halaman pegawai
		return redirect('/printer');
	}
}
