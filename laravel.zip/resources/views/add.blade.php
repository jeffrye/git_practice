<!DOCTYPE html>
<html>
<head>
	<title>Printer</title>
</head>
<body>

	<h3>Data Printer</h3>

	<a href="/printer"> Kembali</a>
	
	<br/>
	<br/>

	<form action="/printer/store" method="post">
		{{ csrf_field() }}
		Nama <input type="text" name="IT Code" required="required"> <br/>
		Jabatan <input type="text" name="Serial" required="required"> <br/>
		Umur <input type="number" name="Brand" required="required"> <br/>
		Alamat <textarea name="Comment" required="required"></textarea> <br/>
		<input type="submit" value="Simpan Data">
	</form>

</body>
</html>