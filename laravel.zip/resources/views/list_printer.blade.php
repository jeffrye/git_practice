@extends('layouts.master')

@section('content')
    <table class="table table-bordered" id="printer-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>IT Code</th>
                <th>Serial Number</th>
                <th>Brand</th>
                <th>IP Address</th>
            </tr>
        </thead>
    </table>
@stop

@push('scripts')
<script>
$(function() {
    $('#printer-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: 'printer/json',
        columns: [
            { data: 'ID', name: 'ID' },
            { data: 'IT_Code', name: 'IT_Code' },
            { data: 'Serial_Number', name: 'Serial_Number' },
            { data: 'Brand', name: 'Brand' },
            { data: 'IP_Address', name: 'IP_Address' }
        ]
    });
});
</script>
@endpush