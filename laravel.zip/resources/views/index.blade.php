<!DOCTYPE html>
<html>
<head>
	<title>Printer</title>
</head>
<body>


	<h3>Data Printer</h3>

	<a href="/printer/add"> + Tambah Printer Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>ID</th>
			<th>IT Code</th>
			<th>Serial Number</th>
			<th>Brand</th>
			<th>&nbsp;</th>
		</tr>
		@foreach($printer as $p)
		<tr>
			<td>{{ $p->ID }}</td>
			<td>{{ $p->IT_Code }}</td>
			<td>{{ $p->Serial_Number }}</td>
			<td>{{ $p->Brand }}</td>
			<td>
				<a href="/printer/edit/{{ $p->ID }}">Edit</a>
				|
				<a href="/printer/delete/{{ $p->ID }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>


</body>
</html>