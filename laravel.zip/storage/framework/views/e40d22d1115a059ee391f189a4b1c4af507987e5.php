<!DOCTYPE html>
<html>
<head>
	<title>Printer</title>
</head>
<body>


	<h3>Data Printer</h3>

	<a href="/printer/add"> + Tambah Printer Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>ID</th>
			<th>IT Code</th>
			<th>Serial Number</th>
			<th>Brand</th>
			<th>&nbsp;</th>
		</tr>
		<?php $__currentLoopData = $printer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($p->ID); ?></td>
			<td><?php echo e($p->IT_Code); ?></td>
			<td><?php echo e($p->Serial_Number); ?></td>
			<td><?php echo e($p->Brand); ?></td>
			<td>
				<a href="/printer/edit/<?php echo e($p->ID); ?>">Edit</a>
				|
				<a href="/printer/delete/<?php echo e($p->ID); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


</body>
</html><?php /**PATH /home/vagrant/code/laravel/resources/views/index.blade.php ENDPATH**/ ?>