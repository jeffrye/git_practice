

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered" id="printer-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>IT Code</th>
                <th>Serial Number</th>
                <th>Brand</th>
                <th>IP Address</th>
            </tr>
        </thead>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#printer-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: 'printer/json',
        columns: [
            { data: 'ID', name: 'ID' },
            { data: 'IT_Code', name: 'IT_Code' },
            { data: 'Serial_Number', name: 'Serial_Number' },
            { data: 'Brand', name: 'Brand' },
            { data: 'IP_Address', name: 'IP_Address' }
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel/resources/views/list_printer.blade.php ENDPATH**/ ?>