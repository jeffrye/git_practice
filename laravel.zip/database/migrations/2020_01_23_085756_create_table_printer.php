<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTablePrinter extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('printer', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->string('IT_Code');
            $table->string('Serial_Number');
            $table->string('Brand');
            $table->string('IP_Address');
            $table->string('Mac_Address');
            $table->string('Location');
            $table->string('Site');
            $table->string('Business_Unit');
            $table->string('Department');
            $table->string('User_Name');
            $table->year('Issuing_Date');
            $table->string('Description');
            $table->string('Status');
            $table->string('Notes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('printer');
    }
}
